library(testthat)
library(velox)

test_check("velox")
